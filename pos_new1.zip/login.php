<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <link rel="shortcut icon" href="#" type="image/png">

    <title>CV. Techindo Global Solusi</title>

    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>  test
    <script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body class="login-body">

    <div class="container">

        <form class="form-signin" action="login-check.php" method="POST">
            <div class="form-signin-heading text-center">
                <img src="assets/images/logoo.jpg" alt="" style="width: 57%; height: auto;"/>
            </div>
            <div class="login-wrap">
                <?php
                error_reporting(0);
                if ($_GET['action'] == 'failed') {
                    ?>
                    <b style="color:red">Login Gagal..!!!</b>
                    <?php
                }
                ?>
                <input type="text" class="form-control" name="frm_username" placeholder="Username" autofocus>
                <input type="password" class="form-control" name="frm_password" placeholder="Password">

                <button class="btn btn-lg btn-login btn-block" type="submit" style="background: #0000CD;">
                    <!-- <i class="fa fa-check"></i> --> Login
                </button>

            </div>
        </form>

    </div>
    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- Placed js at the end of the document so the pages load faster -->
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/modernizr.min.js"></script>

</body>
</html>
